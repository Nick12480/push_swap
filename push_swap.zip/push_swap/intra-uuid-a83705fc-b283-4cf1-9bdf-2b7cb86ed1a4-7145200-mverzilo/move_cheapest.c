/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move_chepest.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mverzilo <mverzilo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/06 14:10:46 by mverzilo          #+#    #+#             */
/*   Updated: 2026/01/12 18:54:41 by mverzilo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

t_stack	*get_cheapest(t_stack *stack)
{
	if (!stack)
		return (NULL);
	while (stack)
	{
		if (stack->cheapest)
			return (stack);
		stack = stack->next;
	}
	return (NULL);
}

void	prep_to_push(t_stack **stack, t_stack *top_node, char stack_name)
{
	while (*stack != top_node)
	{
		if (stack_name == 'a')
		{
			if (top_node->above_median)
				ra(stack);
			else
				rra(stack);
		}
		else if (stack_name == 'b')
		{
			if (top_node->above_median)
				rb(stack);
			else
				rrb(stack);
		}
	}
}

void	move_chepest(t_stack **a, t_stack **b)
{
	t_stack	*chepest_node;

	chepest_node = get_cheapest(*b);
	if (!chepest_node || !chepest_node->target_node)
		return;
	while (*b != chepest_node && *a != chepest_node->target_node)
	{
		if (chepest_node->above_median && \
			chepest_node->target_node->above_median)
			rr(a, b);
		else if (!chepest_node->above_median && \
			!chepest_node->target_node->above_median)
			rrr(a, b);
		else
			break ;
	}
	prep_to_push(b, chepest_node, 'b');
	prep_to_push(a, chepest_node->target_node, 'a');
	pa(a, b);
}

void	min_to_top(t_stack **a)
{
	t_stack	*min_node;

	min_node = find_min(*a);
	prep_to_push(a, min_node, 'a');
}