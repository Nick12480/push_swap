/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Quicksort.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mverzilo <mverzilo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/13 16:48:58 by mverzilo          #+#    #+#             */
/*   Updated: 2026/01/15 16:07:05 by mverzilo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	push_small_values(t_stack **a, t_stack **b, int pivot)
{
	int	size;
	int	rotations;

	size = get_stack_size(*a);
	rotations = 0;
	while (rotations < size && get_stack_size(*a) > 3)
	{
		if ((*a)->index < pivot)
		{
			pb(a, b);
			if (*b && (*b)->next && (*b)->index < pivot / 2)
				rb(b);
			rotations = 0;
		}
		else
		{
			ra(a);
			rotations++;
		}
	}
}

void	push_all_save_three(t_stack **a, t_stack **b)
{
	int	size;
	int	pivot;

	size = get_stack_size(*a);
	if (size <= 3)
		return;
	pivot = size / 2;
	push_small_values(a, b, pivot);
	while (get_stack_size(*a) > 3)
		pb(a, b);
}
