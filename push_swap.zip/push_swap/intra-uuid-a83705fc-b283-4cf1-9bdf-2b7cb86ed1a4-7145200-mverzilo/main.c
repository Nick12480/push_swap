/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mverzilo <mverzilo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/01 17:54:21 by mverzilo          #+#    #+#             */
/*   Updated: 2026/01/15 23:40:42 by mverzilo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	main(int argc, char **argv)
{
	t_stack	*a;
	t_stack	*b;

	a = NULL;
	b = NULL;
	if (argc < 2)
		return (1);
	if (argc == 2 && !argv[1][0])
		return (print_error(), 6);
	if (process_arguments(argc, argv, &a) == 0)
	{
		free_stack(&a);
		print_error();
		return (2);
	}
	if (!(is_sortet(a)))
		seleckt_algorithm(&a, &b);
	free_stack(&a);
	free_stack(&b);
	return (0);
}
