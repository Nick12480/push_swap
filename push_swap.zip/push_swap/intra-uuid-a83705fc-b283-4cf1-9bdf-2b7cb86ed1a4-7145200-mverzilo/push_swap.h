/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mverzilo <mverzilo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/12/21 18:19:14 by mverzilo          #+#    #+#             */
/*   Updated: 2026/01/16 22:08:21 by mverzilo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <limits.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "./libft/libft.h"

typedef struct s_stack
{
	int				value;
	int				index;
	int				pos;
	int				push_cost;
	int				above_median;
	int				cheapest;
	struct s_stack	*target_node;
	struct s_stack	*next;
	struct s_stack	*prev;
}	t_stack;

//Pasing
int			process_arguments(int argc, char **argv, t_stack **stack_a);
int			process_numbers(char **numbers, t_stack **stack);
int			validate_and_add(char *str, t_stack **stack);
void		addto_stack(t_stack **stack, int value);
int			check_duplicate(t_stack	*a, int i);

//Pesing_uten
int			is_valid_number(char *str);
void		free_stack(t_stack	**stack);
void		free_split(char **strs);
int			count_strings(char **strs);
void		print_error(void);

//swap_sa_sb_ss
void		ft_swap(t_stack **stack);
void		sa(t_stack **a);
void		sb(t_stack **b);
void		ss(t_stack **a, t_stack **b);

//push_pa_pb
void		ft_push(t_stack **src, t_stack **dest);
void		pa(t_stack **a, t_stack **b);
void		pb(t_stack **a, t_stack **b);

//rotate_ra_rb_rr
void		ft_rotate(t_stack **stack);
void		ra(t_stack **a);
void		rb(t_stack **b);
void		rr(t_stack **a, t_stack **b);

//reverse_rotate_rra_rrb_rrr
void		ft_rrotate(t_stack **stack);
void		rra(t_stack **a);
void		rrb(t_stack **b);
void		rrr(t_stack **a, t_stack **b);

//push_swap_uten_one
int			is_sortet(t_stack *stack);
int			get_stack_size(t_stack *stack);
void		index_stack(t_stack *a);
void		seleckt_algorithm(t_stack **a, t_stack **b);
t_stack		*find_min(t_stack *stack);

//push_swap_sort_three_four_five
void		sort_three(t_stack **a);
int			find_min_position(t_stack *stack);
void		move_min_to_top(t_stack **stack);
void		sort_five(t_stack **a, t_stack **b);
void		sort_four(t_stack **a, t_stack **b);

//Sorting algorithm "Turk"
void		turk_sort(t_stack **a, t_stack **b);
void		push_all_save_three(t_stack **a, t_stack **b);

//init_nodes_a
void		current_index(t_stack *stack);
void		set_targit_b(t_stack *a, t_stack *b);
void		set_chapest(t_stack *b);
void		cost_analysis_a(t_stack *a, t_stack *b);
void		init_nodes_a(t_stack *a, t_stack *b);

//move_chepst
t_stack		*get_cheapest(t_stack *stack);
void		prep_to_push(t_stack **stack, t_stack *top_node, char stack_name);
void		move_chepest(t_stack **a, t_stack **b);
void		min_to_top(t_stack **a);
void		set_price_a(t_stack *a, t_stack *b);

//push_swap_chunk

int			get_max_value(t_stack *stack);
int			get_min_value(t_stack *stack);
int			calculate_chunk_size(int size);
long		ft_itol(const char *str);
char		**ft_split(char const *s, char c);