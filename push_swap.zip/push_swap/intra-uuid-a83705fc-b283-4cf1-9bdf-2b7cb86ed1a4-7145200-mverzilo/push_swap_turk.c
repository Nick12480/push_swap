/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap_turk.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mverzilo <mverzilo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/02 15:08:35 by mverzilo          #+#    #+#             */
/*   Updated: 2026/01/13 17:10:26 by mverzilo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	turk_sort(t_stack **a, t_stack **b)
{
	push_all_save_three(a, b);
	sort_three(a);
	while (*b)
	{
		init_nodes_a(*a, *b);
		move_chepest(a, b);
	}
	current_index(*a);
	min_to_top(a);
}

// static void	handle_push(t_stack **a, t_stack **b, int median, int *rotations)
// {
// 	if ((*a)->index < median)
// 	{
// 		pb(a, b);
// 		rb(b);
// 		*rotations = 0;
// 	}
// 	else if ((*a)->index < median + median / 2 || *rotations >= get_stack_size(*a))
// 	{
// 		pb(a, b);
// 		*rotations = 0;
// 	}
// 	else
// 	{
// 		ra(a);
// 		(*rotations)++;
// 	}
// }

// void	push_all_save_three(t_stack **a, t_stack **b)
// {
// 	int	size;
// 	int	median;
// 	int	rotations;

// 	size = get_stack_size(*a);
// 	if (size <= 3)
// 		return;
// 	median = size / 2;
// 	rotations = 0;
// 	while (get_stack_size(*a) > 3)
// 	{
// 		if ((*a)->index <= median || rotations > size)
// 		{
// 			pb(a, b);
// 			rotations = 0;
// 		}
// 		else
// 		{
// 			ra(a);
// 			rotations++;
// 		}
// 	}
// }