/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap_parsing.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mverzilo <mverzilo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/12/28 11:37:56 by mverzilo          #+#    #+#             */
/*   Updated: 2026/01/16 14:53:56 by mverzilo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	process_numbers(char **numbers, t_stack **stack)
{
	int	j;

	j = 0;
	while (numbers[j])
	{
		if (!validate_and_add(numbers[j], stack))
			return (0);
		j++;
	}
	return (1);
}

int	process_arguments(int argc, char **argv, t_stack **stack_a)
{
	int		i;
	char	**temp;
	
	i = 1;
	while (i < argc)
	{
		temp = ft_split(argv[i], ' ');
		if (!temp)
			return (0);
		if (!process_numbers(temp, stack_a))
		{
			free_split(temp);
			return (0);
		}
		free_split(temp);
		i++;
	}
	return (1);
}

void	addto_stack(t_stack **stack, int value)
{
	t_stack	*new;
	t_stack	*tmp;

	new = (t_stack *)malloc(sizeof(t_stack));
	if (!new)
		return ;
	new->value = value;
	new->index = -1;
	new->next = NULL;
	if (*stack == NULL)
	{
		*stack = new;
		return ;
	}
	tmp = *stack;
	while (tmp->next)
		tmp = tmp->next;
	tmp->next = new;
}

int	validate_and_add(char *str, t_stack **stack)
{
	long	num;

	if (!is_valid_number(str))
		return (0);
	num = ft_itol(str);
	if (num < INT_MIN || num > INT_MAX)
		return (0);
	if (check_duplicate(*stack, (int)num))
		return (0);
	addto_stack(stack, (int)num);
	return (1);
}

int	check_duplicate(t_stack	*a, int i)
{
	if (!a)
		return (0);
	while (a)
	{
		if (a->value == i)
			return (1);
		a = a->next;
	}
	return (0);
}
