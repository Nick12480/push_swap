/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mverzilo <mverzilo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/11/23 16:22:58 by mverzilo          #+#    #+#             */
/*   Updated: 2025/11/27 17:00:33 by mverzilo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <aio.h>
#include <unistd.h>
#include <string.h>
#include <bsd/string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdarg.h>

int		ft_printf(const char *str, ...);
int		ft_putstr(char *s);
int		convert_ux(unsigned int n, unsigned int base, const char *symbols);
int		convert_p(unsigned long n, unsigned long base, const char *symbols);
int		ft_putnbr(int n);
int		ft_putchar(char c);
int		convert_p_helper(unsigned long n, unsigned long base,\
		const char *symbols);
int		format(const char *str, int i, va_list args);
