/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_nodes_a.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mverzilo <mverzilo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/01/05 18:54:59 by mverzilo          #+#    #+#             */
/*   Updated: 2026/01/13 14:38:42 by mverzilo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	current_index(t_stack *stack)
{
	int	i;
	int	median;

	i = 0;
	if (!stack)
		return ;
	median = get_stack_size(stack) / 2;
	while (stack)
	{
		stack->index = i;
		if (i < median)
			stack->above_median = 1;
		else
			stack->above_median = 0;
		stack = stack->next;
		i++;
	}
}

void	curent_index(t_stack *stack)
{
	int	i;
	int	median;

	i = 0;
	if (!stack)
		return ;
	median = get_stack_size(stack) / 2;
	while (stack)
	{
		stack->index = i;
		if (i < median)
			stack->above_median = -1;
		else
			stack->above_median = 0;
		stack = stack->next;
		i++;
	}
}

void	set_targit_b(t_stack *a, t_stack *b)
{
	t_stack	*curr_a;
	t_stack	*target_nobe;
	long	best_match_index;

	while (b)
	{
		best_match_index = 2147483648;
		curr_a = a;
		while (curr_a)
		{
			if (curr_a->value > b->value && curr_a->value < best_match_index)
			{
				best_match_index = curr_a->value;
				target_nobe = curr_a;
			}
			curr_a = curr_a->next;
		}
		if (best_match_index == 2147483648)
			b->target_node = find_min(a);
		else
			b->target_node = target_nobe;
		b = b->next;
	}
}

void	set_chapest(t_stack *b)
{
	long	cheapest_value;
	t_stack	*cheapest_node;

	cheapest_value = LONG_MAX;
	cheapest_node = NULL;
	if (!b)
		return ;
	while (b)
	{
		if (b->push_cost < cheapest_value)
		{
			cheapest_value = b->push_cost;
			cheapest_node = b;
		}
		b = b->next;
	}
	cheapest_node->cheapest = 1;
}

void	cost_analysis_a(t_stack *a, t_stack *b)
{
	int	len_a;
	int	len_b;

	len_a = get_stack_size(a);
	len_b = get_stack_size(b);
	while (b)
	{
		b->push_cost = b->index;
		if (!(b->above_median))
			b->push_cost = len_b - (b->index);
		
		// NULL-Check hinzugefügt
		if (b->target_node)
		{
			if (b->target_node->above_median)
				b->push_cost += b->target_node->index;
			else
				b->push_cost += len_a - (b->target_node->index);
		}
		b = b->next;
	}
}

void	init_nodes_a(t_stack *a, t_stack *b)
{
	curent_index(a);
	curent_index(b);
	set_targit_b(a, b);
	cost_analysis_a(a, b);
	set_chapest(b);
}
